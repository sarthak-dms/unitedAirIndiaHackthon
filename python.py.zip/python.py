import pandas as pd

# Load CSV data into a DataFrame
df = pd.read_csv('./Datasets/Inflight Service_Inventory data.csv')

# Convert the 'date' column to datetime format
df['scheduled_departure_dtl'] = pd.to_datetime(df['scheduled_departure_dtl'])

# Extract the month and create a new column 'month_id'
df['month_id'] = df['scheduled_departure_dtl'].dt.month

# Print the updated DataFrame
print(df)
